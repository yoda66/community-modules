# Copyright (c) SCYTHE, Inc. Use is subject to agreement.

import argparse
import shlex
import struct
import json


# noinspection PyUnusedLocal
def create_parser(db, os="windows"):
    class ArgumentParser(argparse.ArgumentParser):
        def error(self, message):
            raise ValueError(message)

    parser = ArgumentParser(prog="kerberoast", description="This module finds SPNs and then requests tickets for each user SPN")
    parser.add_argument("-u", "--username", dest="username", type=str, help="User to authenticate as (do not prefix with domain). If not provided the current user context will be used")
    parser.add_argument("-p", "--password", dest="password", type=str, help="Password of user to authenticate as")
    parser.add_argument("-c", "--dc", dest="dc", metavar="1.1.1.1", type=str, help="IP address of domain controller. If not provided the DC will be be lookedup")
    parser.add_argument("--display", dest="display", action="store_true", help="Display tickets after requesting.")
    parser.add_argument("--discover", dest="discover", action="store_true", help="Discovery only. Find the SPNs, don't request the tickets.")

    return parser


def usage(db, os):
    """Return the usage of this module as a string

    :return str: Usage string for this module
    """
    return create_parser(db, os).format_help()


# noinspection PyUnusedLocal
def create_message_body(db, command_line, campaign_name, endpoint_name):
    """Create a SCYTHE message body

    :param db: used only to retrieve operating system
    :param str command_line: command line string. If None is provided, command line will be received from sys.argv
    :param campaign_name: ignored
    :param endpoint_name: ignored
    :return bytes: message body bytes
    """
    # You may call: db.get_setting_value("language")
    # This will return a language id string such as: "en-US"
    # You may use this result to present localized strings in the user interface.

    # You may call: db.get_campaign_operating_system_name(campaign_name)
    # This will return "windows" for Windows campaigns.
    parser = create_parser(db, db.get_campaign_operating_system_name(campaign_name))

    #if not command_line:
    #    raise ValueError("Error: --message argument is missing.")
    #else:
    argv = shlex.split(command_line, posix=False)

    args = parser.parse_args(argv)
    if args:
        return json.dumps(vars(args)).encode("utf-8")
    else:
        return json.dumps({}).encode("utf-8")
    
# noinspection PyUnusedLocal
def report(db, request, response, format_):
    """Generate a report for a request and response for this module

    :param db: ignored
    :param request: Request to report on
    :param response: Response to report on
    :param format_: ignored, always pre
    :return tuple(str, str, str): request report, response report, and format
    """
    # size of the response message is response[64:72]
    sz = struct.unpack("<Q", request[64:72].tobytes())[0]
    request_contents = request[72:72 + sz].tobytes().decode("utf-8")

    content = response[72:].tobytes().decode("utf-8")
    return "\"%s\"" % request_contents, content, "pre"


def main():
    #print(usage(None, None))
    #print(create_message_body(None, "--username administrator --password Bond007 --dc 172.16.105.100", None, None))
    pass


if __name__ == "__main__":
    main()
