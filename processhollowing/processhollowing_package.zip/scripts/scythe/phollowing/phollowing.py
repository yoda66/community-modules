import argparse
import json
import shlex
import re
import struct
import os
import base64
import hashlib
import ctypes
from ctypes import wintypes

from argparse import RawDescriptionHelpFormatter

# Localized Strings
LOCALIZED_HELP_DESCRIPTION_ID = "5000"
LOCALIZED_FILEPATH_FOR_TARGET_ID = "5001"
LOCALIZED_FILEPATH_FOR_SOURCE_ID = "5002"
LOCALIZED_PROCESS_PID_ID = "5003"
LOCALIZED_THREAD_TID_ID = "5004"
LOCALIZED_STATUS_CODE_ID = "5005"
LOCALIZED_STATUS_MESSAGE_ID = "5006"

localized_strings = {
    "en-US":
        {
            "5000": "Replace a target process with a new executable image stored on the Virtual File System (VFS) or local computer. Support is currently for native applications only.",
            "5001": "Filepath of the target executable that will be modified",
            "5002": "Filepath of the source executable to replace target (Path can also be a VFS Path). If the filesize of source executable is too large, process hollowing may fail.",
            "5003": "Process ID",
            "5004": "Thread ID",
            "5005": "Status Code",
            "5006": "Status Message"
        }
}

MAX_STRING_ID_LENGTH = 7
FORMAT_MESSAGE_ALLOCATE_BUFFER = 0x0100
FORMAT_MESSAGE_FROM_SYSTEM = 0x1000
FORMAT_MESSAGE_IGNORE_INSERTS = 0x0200
sys_flag = FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS
__fs = None




def get_agent_strings(db):

    # Default to "en-US"
    language = "en-US"

    # Load global agent_strings for currently selected language
    return localized_strings[language]


def has_vfs_path(source):
    return source.lower().startswith("vfs:/")

def read_vfs_file(path):
    """

    :param path:
    :return:
    """
    global __fs
    if not __fs:
        from vfs import ScytheVFS
        __fs = ScytheVFS()
    return __fs.read_file(path)


def translate_agent_string_ids(db, string_in, agent_strings_json):
    """
    :param db:
    :param str string_in:
    :param dict agent_strings_json:
    :return:
    """

    # replace our localized strings #...#
    matches = re.findall("#\d+#", string_in)
    string_out = string_in

    for match in matches:
        string_id = match[1:-1]
        updated_string = agent_strings_json.get(string_id)
        if not updated_string:
            updated_string = match

        string_out = string_out.replace(match, updated_string)

    return string_out


def get_status_code_message(db, win32_error_code):
    """

    :param db:
    :param win32_error_code:
    :return:
    """

    string_out = ""
    language = "en-US"
    language_id = 0x0409

    # replace win32 errors (in the form #W...#
    bufptr = ctypes.wintypes.LPWSTR()
    chars = ctypes.windll.kernel32.FormatMessageW(sys_flag, None, int(win32_error_code),
                                                  language_id,
                                                  ctypes.byref(bufptr), 0, None)
    if chars == 0:
        chars = ctypes.windll.kernel32.FormatMessageW(sys_flag, None, int(win32_error_code),
                                                      language_id,
                                                      ctypes.byref(bufptr), 0, None)
    if chars != 0:
        string_out = bufptr.value

    ctypes.windll.kernel32.LocalFree(bufptr)
    return string_out

# noinspection PyUnusedLocal
def create_parser(db, os_):
    class ArgumentParser(argparse.ArgumentParser):
        def error(self, message):
            raise ValueError(message)

    agent_strings = get_agent_strings(db)

    epilog = "\nExamples:\n" \
             "  scythe.phollowing --target C:\Windows\System32\calc.exe --src VFS:/users/LOCAL/test/scythe_client.exe\n" \
             "  scythe.phollowing --target C:\Windows\System32\calc.exe --src C:\\Users\\scytheuser\\scythe_client.exe\n"

    parser = ArgumentParser(prog="scythe.phollowing", description=agent_strings[LOCALIZED_HELP_DESCRIPTION_ID], 
                            formatter_class=RawDescriptionHelpFormatter, epilog=epilog)
    parser.add_argument("--target", help=agent_strings[LOCALIZED_FILEPATH_FOR_TARGET_ID], required=True, metavar="path")
    parser.add_argument("--src", help=agent_strings[LOCALIZED_FILEPATH_FOR_SOURCE_ID], required=True, metavar="path")
    return parser


def usage(db, os_):
    """Return the usage of this module as a string

    :return str: Usage string for this module
    """
    return create_parser(db, os_).format_help()


# noinspection PyUnusedLocal
def create_message_body(db, command_line, campaign_name, endpoint_name):
    """Create a Crossbow message body

    :param db:
    :param str command_line: command line string.
    :param campaign_name: ignored
    :param endpoint_name: ignored
    :return str: JSON string with message body
    """

    parser = create_parser(db, db.get_campaign_operating_system_name(campaign_name))

    agent_strings = get_agent_strings(db)
    if not command_line:
        raise ValueError("Missing arguments.  Enter 'help phollowing' for help")
    else:
        argv = shlex.split(command_line, posix=False)

    args = parser.parse_args(argv)

    if args.src is not None:
        args.src = args.src.strip('"')
    if args.target is not None:
        args.target = args.target.strip('"')

    msg = dict()

    if args.src is not None:
        if has_vfs_path(args.src):
            msg['--src'] = args.src

            vfs_file_path = str(args.src)[4:]
            file_contents = read_vfs_file(vfs_file_path)

            if not file_contents:
                raise ValueError(agent_strings[LOCALIZED_SRC_NOT_FOUND_ID])

            msg['--sha256'] = base64.b64encode(hashlib.sha256(file_contents).digest()).decode("utf-8", errors="ignore")
            msg['--content'] = base64.b64encode(file_contents).decode("utf-8", errors="ignore")

        else:
            msg['--src'] = args.src

    if args.target is not None:
        msg['--target'] = args.target

    return json.dumps(msg).encode("utf-8")


# noinspection PyUnusedLocal
def report(db, request, response, format_):
    """Generate a report for a request and response for this module

    :param db:
    :param memoryview request: Request
    :param memoryview response: Response to report on
    :param str format_: ignored, always pre
    :return tuple(str, str, str): request report, response report, and format
    """

    request_size = struct.unpack("<Q", request[64:72].tobytes())[0]
    request_json = json.loads(request[72:72 + request_size].tobytes())
    content = response[72:].tobytes().decode("utf-8", errors="ignore")

    agent_strings = get_agent_strings(db)
    translated_text = translate_agent_string_ids(db, content, agent_strings)

    processhollowing_dict = json.loads(translated_text)

    # translate status code to valid message.
    code = processhollowing_dict[agent_strings[LOCALIZED_STATUS_CODE_ID]]
    processhollowing_dict[agent_strings[LOCALIZED_STATUS_MESSAGE_ID]] = get_status_code_message(db, code)

    ## TODO uncomment lines below if want to remove content value from UI
    # if "--content" in request_json:
    #    request_json.pop("--content")

    if format_ == "json":
        request_contents = request_json
        response_contents = json.dumps(processhollowing_dict)

    else:

        request_contents = " ".join("%s=%s" % (k, v) for k, v in list(request_json.items()))
        response_contents = ""
        for key in processhollowing_dict:
            response_contents += "%s: %s\n" % (key, processhollowing_dict[key])

    return request_contents, response_contents, "pre" if not format_ or format_ not in ("json", "pre") else format_

# noinspection PyUnusedLocal
def succeeded(db, request, response):
    """

    :param db:
    :param memoryview request:
    :param memoryview response:
    :return:
    """

    result = False
    if response and len(response) > 72:
        content = response[72:].tobytes().decode("utf-8", errors="ignore")
        result = content.find("#%s#" % LOCALIZED_PROCESS_PID_ID) != -1

    return result

def schema(db):
    """
    return schema
    :param db:
    :return:

    """
    agent_strings = get_agent_strings(db)
    json_schema = {
        "type": "array",
        "items": {
            "type": "object",
            "properties": {
                agent_strings[LOCALIZED_STATUS_CODE_ID]: {"type": "number"},
                agent_strings[LOCALIZED_PROCESS_PID_ID]: {"type": "number"},
                agent_strings[LOCALIZED_THREAD_TID_ID]: {"type": "number"}

            },
            "required": [
                agent_strings[LOCALIZED_STATUS_CODE_ID]
            ]
        }
    }

    return json.dumps(json_schema, indent=4)

# noinspection PyUnusedLocal
def tags(db, request, response):
    """

    :param db:
    :param memoryview request:
    :param memoryview response:
    :return:
    """

    r = []
    if len(request) > 0:
        r = ["scythe", "att&ck", "att&ck-tactic:TA0004", "att&ck-tactic:TA0005", "att&ck-technique:T1055"]
    return r


def main():
    pass


if __name__ == "__main__":
    main()
