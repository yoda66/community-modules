# Copyright (c) SCYTHE, Inc. Use is subject to agreement.

import argparse
import shlex
import struct
import json


# noinspection PyUnusedLocal
def create_parser(db, os="windows"):
    class ArgumentParser(argparse.ArgumentParser):
        def error(self, message):
            raise ValueError(message)

    epilog = '  scythe.aws --cli "s3 ls"\n'
    parser = ArgumentParser(prog="aws", description="Run AWS cloud commands", epilog=epilog)

    parser.add_argument("--cli", help="AWS CLI ('aws.exe' is prepended)", required=False)
    return parser


def usage(db, os):
    """Return the usage of this module as a string

    :return str: Usage string for this module
    """
    return create_parser(db, os).format_help()


# noinspection PyUnusedLocal
def create_message_body(db, command_line, campaign_name, endpoint_name):
    """Create a SCYTHE message body

    :param db: used only to retrieve operating system
    :param str command_line: command line string. If None is provided, command line will be received from sys.argv
    :param campaign_name: ignored
    :param endpoint_name: ignored
    :return str: String with message body
    """
    parser = create_parser(db, db.get_campaign_operating_system_name(campaign_name))
    if not command_line:
        raise ValueError("Error: arguments are missing.")
    else:
        argv = shlex.split(command_line, posix=False)

    args = parser.parse_args(argv)

    msg_body = dict()
    # We need args.dest and either args.src or args.content
    if args.cli:
        msg_body['cli'] = args.cli

    for i in msg_body:
        if type(msg_body[i]) is str:
            if (msg_body[i].startswith('"') and msg_body[i].endswith('"')) or \
                    (msg_body[i].startswith("'") and msg_body[i].endswith("'")):
                msg_body[i] = msg_body[i][1:-1]
            tokens = shlex.split(msg_body[i])
            for token in tokens:
                if token.startswith("&") or token.startswith("|") or ">" in token or "<" in token:
                    raise ValueError("Error: invalid argument syntax")
    return json.dumps(msg_body).encode("utf-8")


# noinspection PyUnusedLocal
def report(db, request, response, format_):
    """Generate a report for a request and response for this module

    :param db: ignored
    :param request: Request to report on
    :param response: Response to report on
    :param format_: ignored, always pre
    :return tuple(str, str, str): request report, response report, and format
    """
    # size of the response message is response[64:72]
    sz = struct.unpack("<Q", request[64:72].tobytes())[0]
    request_contents = request[72:72 + sz].tobytes().decode("utf-8")

    content = response[72:].tobytes().decode("utf-8")

    request_dict = json.loads(request_contents)
    request_contents = ""
    if "cli" in request_dict:
        request_contents += " --cli " + request_dict['cli']
    return request_contents, content, "pre"


def main():
    pass


if __name__ == "__main__":
    main()
