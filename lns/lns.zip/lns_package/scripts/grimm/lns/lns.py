# Copyright (c) SMFS, Inc. Use is subject to agreement.

import argparse
import shlex
import struct


# noinspection PyUnusedLocal
def create_parser(db, os="windows"):
    class ArgumentParser(argparse.ArgumentParser):
        def error(self, message):
            raise ValueError(message)

    epilog = ' grimm.lns --connect --hosts 192.168.1.1,10.10.10.1,10.10.10.2 --ports 23,22,80,139,443,445,3389'
    parser = ArgumentParser(prog="grimm.lns", description="Network Scanning and Enumeration",
                            epilog=epilog)
    # Host Group - used to specify which host(s) to scan
    host_group = parser.add_mutually_exclusive_group(required=True)
    host_group.add_argument("--hosts", help="Comma seperated list of IP addresses to scan\n\t e.g. --hosts 192.168.1.1,10.10.10.1,10.10.10.2")
    # TODO support CIDR notation
    # host_group.add_argument("--subnet", help="Subnet to scan, denoted by CIDR (e.g. 192.168.1.1/24)")

    scan_group = parser.add_mutually_exclusive_group(required=True)
    scan_group.add_argument("--connect", action='store_true', help="Perform a TCP connect scan")
    # TODO SYN Scan, UDP scan
    #scan_group.add_argument("--stealth", help="Perform a TCP SYN scan")
    #scan_group.add_argument("--udp", help="Perform a UDP scan")

    parser.add_argument("--ports", help="Comma seperated list of ports to scan\n\t e.g. --ports 23,22,80,139,443,445,3389")

    return parser


def usage(db, os):
    """Return the usage of this module as a string

    :return str: Usage string for this module
    """
    return create_parser(db, os).format_help()


# noinspection PyUnusedLocal
def create_message_body(db, command_line, campaign_name, endpoint_name):
    """Create a SCYTHE message body

    :param db: used only to retrieve operating system
    :param str command_line: command line string. If None is provided, command line will be received from sys.argv
    :param campaign_name: ignored
    :param endpoint_name: ignored
    :return str: String with message body
    """

    # You may call: db.get_setting_value("language")
    # This will return a language id string such as: "en-US"
    # You may use this result to present localized strings in the user interface.

    # You may call: db.get_campaign_operating_system_name(campaign_name)
    # This will return "windows" for Windows campaigns.

    parser = create_parser(db, db.get_campaign_operating_system_name(campaign_name))

    if not command_line:
        raise ValueError("Error: Argument string missing")
    else:
        argv = shlex.split(command_line, posix=False)

    args = parser.parse_args(argv)        
            
    # We need args.dest and either args.src or args.content
    if args.connect != True:    
        raise ValueError("Error: --connect argument is missing.")
    else:
        if not args.hosts:
            raise ValueError("Error: --hosts argument is missing.")
        if not args.ports:
            raise ValueError("Error: --ports argument is missing.")
    
    good_chars = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ',', '.']
    if any([char for char in args.hosts if char not in good_chars]):
        raise ValueError("Error: Invalid character in host list")
    if any([char for char in args.ports if char not in good_chars]):
        raise ValueError("Error: Invalid character in port list")

    # validate IP addresses
    for host in args.hosts.split(","):
        stripped_host = host.replace(".", "")
        max_ip_as_direct_int = 255255255255
        try:
            print(stripped_host)
            int(stripped_host)
        except ValueError:
            raise ValueError("Error: Invalid IP address " + host)

        if max_ip_as_direct_int <= int(stripped_host):
            raise ValueError("Error: Invalid IP address " + host)

    # validate ports
    check_ports = args.ports.strip(".")
    for port in check_ports.split(","):
        if 0 >= int(port) or int(port) > 65535:
            raise ValueError("Error: Invalid port " + port)


    return bytes(f'connect:{args.hosts.strip(" ")}:{args.ports.strip(" ")}', "ASCII")


# noinspection PyUnusedLocal
def report(db, request, response, format_):
    """Generate a report for a request and response for this module

    :param db: ignored
    :param request: Request to report on
    :param response: Response to report on
    :param format_: ignored, always pre
    :return tuple(str, str, str): request report, response report, and format
    """
    # size of the response message is response[64:72]
    sz = struct.unpack("<Q", request[64:72].tobytes())[0]
    request_contents = request[72:72 + sz].tobytes().decode("utf-8")
    content = response[72:].tobytes().decode("utf-8")
    return request_contents, content, "pre"



def main():
    pass


if __name__ == "__main__":
    main()
