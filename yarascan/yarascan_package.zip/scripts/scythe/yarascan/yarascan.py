# Copyright (c) SCYTHE, Inc. Use is subject to agreement.

import argparse
import shlex
import struct
import json
import base64
import string

def has_vfs_path(source):
    return source.lower().startswith("vfs:/")

def read_vfs_file(path):
    """

    :param path:
    :return:
    """
    global __fs
    if not __fs:
        from vfs import ScytheVFS
        __fs = ScytheVFS()
    return __fs.read_file(path)

# noinspection PyUnusedLocal
def create_parser(db, os="windows"):
    class ArgumentParser(argparse.ArgumentParser):
        def error(self, message):
            raise ValueError(message)

    epilog =  '  scythe.yarascan --rule "VFS:\\yara_rule.yara --file file_to_scan.exe"\n'
    parser = ArgumentParser(prog="yarascan", description="Echo the request back as response",
                            epilog=epilog)
    parser.add_argument("--rule", help="Yara rule file which is currently located on your SCYTHE VFS share.", required=True)
    parser.add_argument("--filename", help="The file you want to scan with the yara rule.", required=False)
    parser.add_argument("--directory", help="The directory you want to scan with the yara rule.", required=False)
    parser.add_argument("--recurse", help="Search directory recursively.", default=False)
    return parser


def usage(db, os):
    """Return the usage of this module as a string

    :return str: Usage string for this module
    """
    return create_parser(db, os).format_help()


# noinspection PyUnusedLocal
def create_message_body(db, command_line, campaign_name, endpoint_name):
    """Create a SCYTHE message body

    :param db: used only to retrieve operating system
    :param str command_line: command line string. If None is provided, command line will be received from sys.argv
    :param campaign_name: ignored
    :param endpoint_name: ignored
    :return bytes: message body bytes
    """
    # You may call: db.get_setting_value("language")
    # This will return a language id string such as: "en-US"
    # You may use this result to present localized strings in the user interface.

    # You may call: db.get_campaign_operating_system_name(campaign_name)
    # This will return "windows" for Windows campaigns.
    parser = create_parser(db, db.get_campaign_operating_system_name(campaign_name))

    if not command_line:
        raise ValueError("Error: This module requires arguments.")
    else:
        argv = shlex.split(command_line, posix=False)

    args = parser.parse_args(argv)
    # We need args.rule and either args.directory or args.filename
    if not args.rule:
        raise ValueError("Error: --rule argument is missing.")
    if not args.filename and not args.directory:
        raise ValueError("Error: --filename or --directory argument is missing")
    else:
        file_contents = None
        if not has_vfs_path(args.rule):
            #raise ValueError("Error: --rule must be uploaded to the VFS")
            file_contents = open(args.rule, 'r').read()
        else:
            vfs_file_path = str(args.rule)[4:]
            file_contents = read_vfs_file(vfs_file_path).decode('utf-8')

        # Need to check that this succeeds.
        if not file_contents:
            raise ValueError("File not found")

        # Need to check if the file is ascii readable, making this
        # into a dictionary in case of larger files
        printable_dict = {}
        for i in string.printable:
            printable_dict[i] = 1

        for val in file_contents:
            if val not in printable_dict:
                raise ValueError("Invalid file, all contents must be ascii")

        message_dictionary = {}
        message_dictionary['rule'] = file_contents
        message_dictionary['rule_name'] = args.rule

        if args.filename:
            message_dictionary['filename'] = args.filename
        elif args.directory:
            message_dictionary['directory'] = args.directory

            if args.recurse:
                message_dictionary['recurse'] = args.recurse

        args.message = json.dumps(message_dictionary)

    return args.message.encode("utf-8")


# noinspection PyUnusedLocal
def report(db, request, response, format_):
    """Generate a report for a request and response for this module

    :param db: ignored
    :param request: Request to report on
    :param response: Response to report on
    :param format_: ignored, always pre
    :return tuple(str, str, str): request report, response report, and format
    """
    # size of the response message is response[64:72]
    sz = struct.unpack("<Q", request[64:72].tobytes())[0]
    request_contents = request[72:72 + sz].tobytes().decode("utf-8")
    message_dict = json.loads(request_contents)

    request_command_line = ""

    if 'rule_name' in message_dict:
        request_command_line += "--rule %s " % message_dict['rule_name']

    if 'filename' in message_dict:
        request_command_line += "--filename %s" % message_dict['filename']

    if 'directory' in message_dict:
        request_command_line += "--directory %s" % message_dict['directory']

    content = response[72:].tobytes().decode("utf-8")
    content_formatted = "The following files matched the rule:\n"

    # Check for the error string here
    if "Error:" in content:
        content_formatted = content

    elif content != "No matches found for rule":
        content_formatted = "The following files matched the rule:\n"
        content_formatted += content
    else:
        if 'filename' in message_dict:
            content_formatted = "File %s did not match rule" % message_dict['filename']
        elif 'directory' in message_dict:
            content_formatted = "No file in directory %s matched rule" % message_dict['directory']
        else:
            content_formatted = "Error: no filename or directory specified"

    return request_command_line, content_formatted, "pre"

# noinspection PyUnusedLocal
def succeeded(db, request, response):
    """

    :param db:
    :param memoryview request:
    :param memoryview response:
    :return:
    """
    result = False
    if response and len(response) > 72:
        content = response[72:].tobytes().decode("utf-8")
        if not "Error:" in content:
            result = True

    return result

# noinspection PyUnusedLocal
def tags(db, request, response):
    """

    :param db:
    :param memoryview request:
    :param memoryview response:
    :return:
    """
    r = []
    if len(request) > 0:
        r = ["scythe", "att&ck", "att&ck-tactic:TA0009", "att&ck-technique:T1119"]
    return r


def main():
    pass


if __name__ == "__main__":
    main()
